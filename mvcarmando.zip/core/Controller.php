<?php

namespace armando\core;


/**
 * Class Controller
 * 
 * @author Marco Antonio Rodriguez Salinas <alekas_oficial@outlook.com>
 * @package app\core
 */
class Controller {
    
    
   /* public function render($vista, $parametros = []){
      
        return Aplicacion::$app->ruta->vistaPlantilla($vista, $parametros);
    }*/
   

}
