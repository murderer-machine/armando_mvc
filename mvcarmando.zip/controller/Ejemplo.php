<?php

namespace armando\controller;

use armando\core\Controller;
use alekas\core\Request;

class Ejemplo extends Controller{

    public function ejemplo1(Resquest $request) {
      
             
        echo 'hola soy ejemplo1';
    }

    public function ejemplo2() {
        echo 'hola soy ejemplo2';
    }

}
