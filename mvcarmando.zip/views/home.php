@plantilla('web')

@bloque('titulo')
hola soy titulo
@fin


@bloque('cuerpo')
<p>hola soy paffrafo de vista</p>
@fin