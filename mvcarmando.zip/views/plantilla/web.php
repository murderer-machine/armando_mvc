
<!DOCTYPE html>
<html>
<head>
<title>@bloque('titulo')</title>
</head>
<body>

@bloque('cuerpo')

</body>
</html>