<?php

require_once '../vendor/autoload.php';

use armando\core\Aplicacion;
use armando\controller\Ejemplo;

$url = $_GET['alekas_url'] ?? "/";

$app = new Aplicacion($url, dirname(__DIR__));
$app->ruta->get('/',[Ejemplo::class,'ejemplo1']);
$app->ruta->get('home','home');
$app->ruta->get('contacto','contacto');
$app->ruta->post('imagenes','imagenes');
$app->Run();




